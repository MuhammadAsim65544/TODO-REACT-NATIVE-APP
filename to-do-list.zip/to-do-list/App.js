import React,{useState} from 'react';
import {View,Text,StyleSheet,FlatList,ScrollView,Alert,TouchableWithoutFeedback,Keyboard} from 'react-native';
import Header from './components/Header';
import Todos from './components/Todos';
import AddToDO from './components/AddToDo';

export default function App(){
  const [todos,setTodos]=useState([
  {text:'Buy coffee', key:'1'},
  {text:'Create an App', key:'2'},
  {text:'Play on the switch', key:'3'},
  {text:'Watch Osman episode', key:'4'},
  {text:'Pubg Live Stream', key:'5'},
  {text:'Watch Remaining videos of tutorial', key:'6'},
  {text:'Read the Quran', key:'7'},
  {text:'Go For Walk', key:'8'},
  {text:'Think about yourself before to asleep', key:'9'},
]);
const pressHandler=(key)=>{
  setTodos((prevTodos)=>{
    return prevTodos.filter(todo=>todo.key !=key);
  })
}

const submitHander=(text)=>{
  if(text.length > 3){
    setTodos((prevTodos)=>{
      return [
        {text:text,key:Math.random().toString() },
        ...prevTodos
      ]
    });
  }else{ // alert(title,message,button)
    Alert.alert('OOPS','Todos must be greater than 3 characters',[{
      text:'Understood',onPress:()=>console.log('Alert closed')
    }])
  }
}

  return(
    <TouchableWithoutFeedback onPress={()=>{
      Keyboard.dismiss();
      console.log('Keyboard closed.')
    }}>
      <View style={styles.container}>
      <ScrollView>
        <Header/>
        <View styles={styles.content}>
          <AddToDO submitHander={submitHander}/>
          <View style={styles.list}>
            <FlatList
              data={todos}
              renderItem={({item})=>(
                <Todos item={item} pressHandler={pressHandler} />
              )}
            />
          </View>
        </View>
      </ScrollView>
      </View>
    </TouchableWithoutFeedback>
  );
}
const styles=StyleSheet.create({
  container:{
    flex:1,
    marginTop:25,
  },
  content:{
        flex:1,
    padding:30,
    backgroundColor:'red',
  },
  list:{
        flex:1,
    paddingTop:10,
 },
 
});