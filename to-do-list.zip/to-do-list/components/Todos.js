import React from 'react';
import {View, Text, StyleSheet,TouchableOpacity} from 'react-native';
import { Feather } from '@expo/vector-icons';

export default function Todos({ item, pressHandler }){//Array destructuring
  return(
    <View style={styles.container}>
      < TouchableOpacity style={styles.button} onPress={()=>pressHandler(item.key)}> 
        <View style={styles.item}>
            <Feather name="delete" size={25}/>
            <Text style={styles.text}>{item.text} </Text>
        </View>
      </TouchableOpacity>
      
    </View>
  )
}
const styles=StyleSheet.create({
  container:{
    width:360,
  },
  button:{
    backgroundColor: 'pink',
  },
  item:{
    flexDirection:'row',
    width:358,
    padding:14,
    marginTop:16,
    borderWidth:3,
    borderColor:'red',
    borderStyle:'dashed',
    borderRadius:10,
  },
  text:{
    paddingLeft:15,
    fontSize:15,
    fontWeight:'bold',
  }
})