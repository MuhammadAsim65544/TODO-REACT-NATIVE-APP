import React from 'react';
import {View,Text,StyleSheet} from 'react-native';

export default function Header(){
  return(
    <View style={styles.header}>
      <Text style={styles.title}>MY TODOS</Text>
    </View>
  );
}
const styles=StyleSheet.create({
  header:{
    height:50,
    backgroundColor:'coral'
  },
  title:{
    paddingTop:15,
    textAlign:'center',
    color:'white',
    fontSize:15, 
    fontWeight:'bold',
  }

});
