import React,{useState} from 'react';
import {View,Text,StyleSheet,TextInput,Button} from 'react-native';


export default function ToDO({submitHander}){
  const [text,setText]=useState('');
  const changeHandler=(val)=>{
    setText(val);
  }
  return(
    <View>
      <TextInput
        multiline
        style={styles.input}
        placeholder='new todo'
        
        onChangeText={changeHandler}
        
      />
      <Button  onPress={()=>submitHander(text)} title='ADD Todo' color='blue'/>
    </View>
  )
}
const styles=StyleSheet.create({
  input:{
    backgroundColor:'yellow',
    height:20,
    width:330,
    marginTop:30,
    marginBottom:10,
    marginHorizontal:8,
    marginVertical:6,
    borderBottomWidth:2,
    borderBottomColor:'#ddd'
    
  }
})